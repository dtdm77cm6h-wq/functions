
// let a= 7;
// let b= 3;

// sum = a + b;
// difference = a - b;
// product = a * b;

// console.log("Сумма:", sum);
// console.log("Разность:", difference);
// console.log("Произведение:", product);


// let fname= "Kausar";
// let lname= "Kayrbay";
// let fullname= fname + " "+ lname;
// console.log(fullname);


// let city = "Astana";
// let result= city+ " is capital";
// console.log(result); 



// let language = "JavaScript";
// let learn= "I learn "+ language;
// console.log(learn);


// let word = "Hello";
// let result= word + " " + word;
// console.log(result);


// // Создай переменную text = "JS"
// // Создай строку "JS is awesome!" используя конкатенацию.
// let text = "JS";
// let message = text + " is awesome!";
// console.log(message);

