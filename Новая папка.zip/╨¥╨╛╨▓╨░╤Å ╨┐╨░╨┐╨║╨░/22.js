// // 1
// let n = 90;
// if (n>0) {
//     console.log("positive");
// } else if (n<0) {
//     console.log("negative");
// } else if(n==0) {
//     console.log("zero");
// }

// // 2
// let m= 17;
// if (m<7) {
//     console.log("rebenok");
// } else if (7<=m<=17) {
// console.log("shkolnik");
// } else if (17<=m<=22) {
//     console.log("student");
// } else{
//     console.log("vzroslyi");
// } 

// // 3
// let n = -3;
// if (n%2==0) {
//     console.log("even");
// } else {
//     console.log("odd");
// }


// // 4
// let score = 5;
// switch(score) {
//     case 5: 
//     console.log("excellent");
//     break;
//     case 4:
//         console.log("good");
//         break;
//     case 3:
//         console.log("norm");
//         break;
//     case 2:
//         console.log("bad");
//         break;
//         case 1:
//         console.log("awful");
//         break;
//     default:
//         console.log("takogo balla net");
// }


// // 5
// let a= 10;
// let b= 20;

// if (a<b) {
//     console.log(b);
// } else {
//     console.log(a);
// }

// // 6
// for (let y=1; y<=10; ++y) {
//     console.log(y);
// }

// // 7
// let n = 3;
// let sum = 0;
// for (let i=1; i<=n; i++) {
//     sum += i;
// }
// console.log(sum);

// //8
// for (let i=1; i<=50; i%2==0) {
//     console.log(i);
// }

// //9
// let n=5;
// for( let i=1; i<=10; i++) {
//     console.log(`${n} * ${i} = ${n*i}`);
// }

// //10

// let i=10;
// while (i>=1) {
//     console.log(i);
//     i--;
// }       


// // 12

// let n = 5;
// let factorial = 1;
// for (let i = 1; i <= n; i++) {
//     factorial *= i;
// }
// console.log(factorial);

// // 13

// for (let num = 2; num <= 100; num++) {
//     let isPrime = true;
//     for (let i = 2; i <= Math.sqrt(num); i++) {
//         if (num % i === 0) {
//             isPrime = false;
//             break;x
//         }
//     }
//     if (isPrime) {
//         console.log(num);
//     }
// }


// // 14. Среднее значение

// // Дан массив чисел.
// // Найти среднее арифметическое.
// let numbers = [10, 20, 30, 40, 50];
// let sum = 0;

// for (let i = 0; i < numbers.length; i++) {
//     sum += numbers[i];
// }

// let average = sum / numbers.length;
// console.log(average);   
 

// 15. Лестница

// Используя цикл, вывести:
// *
// **
// ***
// ****
// *****
// let stairs = 5;
// let pattern = "";

// for (let i = 1; i <= stairs; i++) {
//     pattern += "*";
//     console.log(pattern);
// }       
